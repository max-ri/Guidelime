Guidelime.registerGuide([[
[D *My* own guide for Guidelime \\ http://www.twitch.tv/mytwitch]  
[GA Alliance]
[N1-6 My guide Part 1]
[NX6-12 My guide Part 2]
[QA123]
[QC123]
[QT123]
]], 'My Guides')
-- See https://github.com/max-ri/Guidelime/wiki/WriteAGuide for instructions on how to write a guide.
-- You can use *asterisks* for highlighting and \\ for linebreaks.
-- The text 'My Guides' in the last line defines in which group your guide appears in the guides list. Use the same name for all of your guides.
